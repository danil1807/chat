package ru.geekbrains.chat.client;

public class ClientTwo {
    public static void main(String[] args) {
        new ClientChat();
    }
}
